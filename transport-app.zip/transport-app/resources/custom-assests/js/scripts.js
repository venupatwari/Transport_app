$(document).ready(function()
{
	
	
	
//	$("#dated").val("03-07-2017");
	
$(".savelrno_btn").on('click',function()
										   {
	
												console.log('working');
												
												var Err_cnt='0';
												
												var dated = $("#dated").val();
													dated = $.trim(dated);
													
													if(dated=='')
													{
														Err_cnt='1';
														//$("#dated").css({"border":"1px solid #ff0124"});
														$("#dated").addClass('err-border');
													}
													else	
														$("#dated").removeClass('err-border').addClass('remove-err-border');
														
												var Vehicle_No = $("#Vehicle_No").val();
													Vehicle_No = $.trim(Vehicle_No);
												
												if( Vehicle_No == '')
												{
													Err_cnt='1';
													$("#Vehicle_No").addClass('err-border');
												}
												else
													$("#Vehicle_No").removeClass('err-border').addClass('remove-err-border');
													

												var Vehicle_Hire = $("#Vehicle_Hire").val();	
													Vehicle_Hire = $.trim(Vehicle_Hire);
												
												if( Vehicle_Hire == '' )
												{
													Err_cnt='1';
													$("#Vehicle_Hire").addClass('err-border');	
												}
												else
												{
													
													//console.log( typeof( parseFloat(Vehicle_Hire))	);
													
													Vehicle_Hire = parseFloat(Vehicle_Hire);
													
													if(Vehicle_Hire>0)
													{
														$("#Vehicle_Hire").removeClass('err-border').addClass('remove-err-border');	
													}
													else
													{
														Err_cnt='1';
														$("#Vehicle_Hire").addClass('err-border');
													}
												}
												
												
												var Vehicle_Hamali = $("#Vehicle_Hamali").val();
													Vehicle_Hamali = $.trim(Vehicle_Hamali);
												
												var Driver_Name = $("#Driver_Name").val();
													Driver_Name = $.trim(Driver_Name);
												
												var Consignor = $("#Consignor").val();
													Consignor = $.trim(Consignor);
												
												var Consignee = $("#Consignee").val();
													Consignee = $.trim(Consignee);
												
												var mobilenumber = $("#mobilenumber").val();
													mobilenumber = $.trim(mobilenumber);
													
												var noAtricles = $("#noAtricles").val();
													noAtricles = $.trim(noAtricles);
												
												var remarks = $("#remarks").val();
													remarks = $.trim(remarks);
												
												var Articledescription = $("#Articledescription").val();
													Articledescription = $.trim(Articledescription);
												
												var size = $("#size").val();
													size = $.trim(size);
													
											 	var dimensions = $("#dimensions").val();
													dimensions = $.trim(dimensions);
													
												var FromPlace = $("#FromPlace").val();
													FromPlace = $.trim(FromPlace);
													
													
												
												if( FromPlace == "select" )
												{
													Err_cnt='1';
													$("#FromPlace").addClass('err-border');	
												}
												else
													$("#FromPlace").removeClass('err-border').addClass('remove-err-border');	
												
												var ToPlace = $("#ToPlace").val();
													ToPlace = $.trim(ToPlace);
												
												if( ToPlace == "select" )
												{
													Err_cnt='1';
													$("#ToPlace").addClass('err-border');
												}
												else
													$("#ToPlace").removeClass('err-border').addClass('remove-err-border');	
												
												var LRNO = $("#LRNO").val();
													LRNO = $.trim(LRNO);

												if( LRNO == "" )
												{
													Err_cnt='1';
													$("#LRNO").addClass('err-border');
												}
												else
													$("#LRNO").removeClass('err-border').addClass('remove-err-border');	
												
												
												var paidat = $("#paidat").val();
													paidat = $.trim(paidat);
												
												
												var ToPay = $("#ToPay").val();
													ToPay = $.trim(ToPay);
													
												var hamalicharges = $("#hamalicharges").val();
													hamalicharges = $.trim(hamalicharges);
													
												var paid = $("#paid").val();
													paid = $.trim(paid);
													
												if(paidat=="0")
													{
														Err_cnt='1';
														$("#paidat").addClass('err-border');
													}
													else
													{
														
														if( paidat=="Hyd" || paidat == "Sec")
														{
															
															if( ToPay=="")	
															{
																Err_cnt='1';
																$("#ToPay").addClass('err-border');	
															}
															else
																$("#ToPay").removeClass('err-border').addClass('remove-err-border');	

														if( paid=="" )
															{
																Err_cnt='1';
																$("#paid").addClass('err-border');
															}
															else
																$("#paid").removeClass('err-border').addClass('remove-err-border');	
															
														}
														else if( paidat=="Vkb")
														{
															$("#paid").removeClass('err-border').addClass('remove-err-border');	
															
															if( ToPay=="")	
															{
																Err_cnt='1';
																$("#ToPay").addClass('err-border');	
															}
															else
																$("#ToPay").removeClass('err-border').addClass('remove-err-border');
																
															var hamalicharges = $("#hamalicharges").val();
																hamalicharges = $.trim(hamalicharges);
																
																if( hamalicharges=="")
																{
																	Err_cnt='1';
																	$("#hamalicharges").addClass('err-border');
																}
																else
																	$("#hamalicharges").removeClass('err-border').addClass('remove-err-border');
																
														}
														
														
															
													}

												if(Err_cnt=='0')
												{
													
													$.ajax({
													
																url:'Requestdispatcher.php?func=adddata',
																type:"POST",
																data:{"dated":dated,"Vehicle_No":Vehicle_No,"Vehicle_Hire":Vehicle_Hire,"Vehicle_Hamali":Vehicle_Hamali,"Driver_Name":Driver_Name,"FromPlace":FromPlace,"ToPlace":ToPlace,"Consignor":Consignor,"Consignee":Consignee,"mobilenumber":mobilenumber,"noAtricles":noAtricles,"remarks":remarks,"Articledescription":Articledescription,"size":size,"dimensions":dimensions,"LRNO":LRNO,"paidat":paidat,"ToPay":ToPay,"hamalicharges":hamalicharges,"paid":paid},
																success:function(resp)
																{
																	resp=$.trim(resp);
																	
																	if(resp=="1")
																	{
																		$(".transport_data_msg").html("<span class='alert alert-success'>Data added successfully</span>");
																		$("form#transport_dataform")[0].reset();
																	}
																	else
																	{
																		$(".transport_data_msg").html("<span class='alert alert-danger'>Unable to add data plz contact admin</span>");
																	}
																
																}//success function ends here
													
													});	//ajax ends here
												}
												
										   });// savelrno_btn click ends here
	
 
 
 //get customer due amnount
 
 $(document).on('click','.search_fromto',function()
												  {
													  var Err_cnt='0';
													  
													 var bycustomer = $(".bycustomer").val();
													 	bycustomer = $.trim(bycustomer);
														
														if( bycustomer !="")
														{
															$(".bycustomer").removeClass('err-border').addClass('remove-err-border');
															
															
															$.ajax({ 
																   	url:'Requestdispatcher.php?func=getcustomerdue',
																	type:'POST',
																	data:{"Customer":bycustomer},
																	success:function(resp)
																	{
																		resp = $.trim(resp);
																		
																		if(resp!='0')
																		{
																			
																			var pay = resp.split("::");	
																			
																			$(".customername").	html(bycustomer);
																			$(".notyetpaid").css({'display':'block'});
																			$(".duration-total-amount").html(pay[0]);
																			$(".Nill-due-amount").html(pay[1]);
																			
																			if(pay[2]!='0')
																			{
																				$(".paidhistory").css({'display':'block'});	
																				$(".paidhistory").html(pay[2]);
																				
																			}
																			else
																			{
																				$(".paidhistory").html('');
																				$(".paidhistory").css({'display':'none'});	
																			}
																			
																		}
																		
																	}
																   });
															
															
														}
														else
															{
																Err_cnt='1';	
																$(".bycustomer").addClass('err-border');
															}
												  });
 
 //get customer due amount ends here
 
 
 //get the cheque section on when user clicks on cheque radio button
 
$(".Cash_Cheque").on('click',function()
									  {
										 	var cheque_cash = $(this).val(); 
												cheque_cash = $.trim(cheque_cash);
												
												if(cheque_cash=="cheque")
												{
													$(".cash-cheque-err").html('');
													$(".chequedetails").css({"display":'block'});
												}
												else if( cheque_cash == "cash")
												{
													$(".cash-cheque-err").html('');
													$("#chequeno").val('');
													$("#bank").val('');
													$(".chequedetails").css({"display":'none'});	
												}
});



//hanglind the disocunts and deducting that amount form the total payable amount


$("#discount_in").on('change',function()
									   {
										  var flat_percentage = $(this).val();
										  var discount = $("#discount").val();
											  
										  if(flat_percentage=='0')
										  {
											  $("#discount").removeClass("err-border");
										  }
										  else
										  {
											  
												if(flat_percentage=="flat")
												{
													if(discount=="")
													{
														Err_cnt='1';
														$("#discount").addClass("err-border");
													}
													else
													{
														discount = parseFloat(discount);
														
														var bycustomer = $(".bycustomer").val();
															bycustomer  = $.trim(bycustomer);
															
															if(bycustomer =='')
															{
																Err_cnt='1';
																$(".bycustomer").addClass('err-border');
															}
															else
															{
																$(".bycustomer").removeClass('err-border');
																$(".search_fromto").trigger('click');
															}
														
														
													}
												}
												else if(flat_percentage=="percentage")
												{
													
													if(discount=='')
													{
														Err_cnt='1';
														$("#discount").addClass("err-border");
													}
													else
													{
														discount = parseFloat(discount);	
													}
													
												}
												
													
										  }
										  
										  
										  
									   });


//validating add payment

$(document).on('click','#adpayment_btn',function()
												 {
													var Err_cnt='0';
													
													var bycustomer = $(".bycustomer").val();
														bycustomer = $.trim(bycustomer);
														
													
													if(bycustomer=='')
														{
															
															Err_cnt='1';
															$(".bycustomer").addClass('err-border');
															
														}
														else 
														{
															$(".bycustomer").removeClass('err-border');
															
															var Totalamount = $("#Totalamount").val();
																Totalamount = $.trim(Totalamount);
																
																if(Totalamount!='')
																{
																	Totalamount = parseFloat(Totalamount);
																	
																	if(Totalamount>0)
																	{
																		$("#Totalamount").removeClass('err-border');	
																	}
																	else
																	{
																		Err_cnt='1';
																		$("#Totalamount").addClass('err-border');	
																	}
																}
																else
																{
																	Err_cnt='1';
																	$("#Totalamount").addClass('err-border');
																}
															
														}
														
														if( $(".Cash_Cheque").is(':checked'))
														{
															
															$(".cash-cheque-err").html('');
															
															var cheque_cash = $('.Cash_Cheque:checked').val();
															
															cheque_cash = $.trim(cheque_cash);
															
															
															if(cheque_cash=="cheque")
															{
														
															var chequeno = 	$("#chequeno").val();
																chequeno = $.trim(chequeno);
																
															 var bank = $("#bank").val();
																bank = $.trim(bank);
															
															if( chequeno=='')
															{
																Err_cnt='1';
																$("#chequeno").addClass('err-border');
															}
															else
															{
																$("#chequeno").removeClass('err-border');
															}
															if(bank=='')
															{
																Err_cnt='1';
																$("#bank").addClass('err-border');
															}
															else
															{
																$("#bank").removeClass('err-border');
															}
																
															}
														}
														else
														{
																Err_cnt='1';
																$(".cash-cheque-err").html('Select cash or cheque');
														}
														
														
														
														//handle the discount 
														
														var discount = $("#discount").val();
															discount = $.trim(discount);
															
														var discount_in = $("#discount_in").val();
															discount_in = $.trim(discount_in);
															
														var payingAmount = $("#Totalamount").val();
															payingAmount =$.trim(payingAmount);
														
														var chequeno = '';
														var bank = '';
														
														if( $(".Cash_Cheque").is(':checked'))
														{
															var Cash_Cheque = $(".Cash_Cheque:checked").val();
																Cash_Cheque = $.trim(Cash_Cheque);
															
															if(Cash_Cheque=="cheque")
															{
														
																var chequeno = 	$("#chequeno").val();
																	chequeno = $.trim(chequeno);
																
																 var bank = $("#bank").val();
																	bank = $.trim(bank);
															}	
														}
														
														
														var dueamount = $(".Nill-due-amount").text();
															dueamount = $.trim(dueamount);
														
														if(Err_cnt=='0')
														{
															$.ajax({
																   	url:'Requestdispatcher.php?func=addpayment',
																	type:"POST",
																	data:{"bycustomer":bycustomer ,"discount":discount, "discount_in":discount_in,"payingAmount":payingAmount, "Cash_Cheque":Cash_Cheque,"chequeno":chequeno,"bank":bank,"dueamount":dueamount  },
																	success:function(resp)
																	{
																		resp = $.trim(resp);
																		
																		if(resp=='1')
																		{
																			$(".pay_msg").html("<span class='alert alert-success'>Payment successfully</span>");	
																			$("form#bymultipledates")[0].reset();
																			$("form#payment_form")[0].reset();
																			$(".customername").html('');
																			$(".duration-total-amount").html('');
																			$(".Nill-due-amount").html('');
																			
																			$(".notyetpaid").css({'display':'none'});
																			$(".chequedetails").css({'display':'none'});
																			
																			$(".paidhistory>").html('');
																			$(".paidhistory").css({'display':'none'});
																			
																			
																		}
																		else
																		{
																		$(".pay_msg").html("<span class='alert alert-danger'>payment failed</span>");	
																		}
																	}
																   
																   });//ajax ends here
														}
														
														
												 });

 
});//document ready ends here