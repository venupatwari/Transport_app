<!-- Transport modal pop up ends here-->
<div class="modal fade" id="transport" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                            <h4 class="modal-title POPUP-LRNO" id="myModalLabel">Modal title Here</h4>
                                        </div>
                                        <div class="modal-body transportpopupdata">
                                            
                                        <div class="col-md-6 name"  style="border:1px solid #eee">
                                        
                                        <p><span class="labell">Customer Name:</span> <span class="CustomerName value"></span></p>
                                        <p><span class="labell">Mobile Number:</span><span class="MobileNumber value"></span><span class="clearfix"></span></p>
                                        <p><span class="labell">Dispatch Material:</span><span class="DispatchMaterial value"></span></p>
                                        <p><span class="labell">Size:</span> <span class="Size value"></span></p>
                                        <p><span class="labell">Quantity:</span> <span class="Quantity value"></span></p>
                                        <p><span class="labell">From Place:</span> <span class="FromPlace value"></span></p>
                                        <p><span class="labell">To Place:</span> <span class="ToPlace value"></span></p>
                                        
                                        
                                        </div>
                                        
                                        <div class="col-md-6 name"  style="border:1px solid #eee">
                                        <p><span class="labell">Transport Amount: </span><span class="TransportAmount value" ></span></p>
                                        <p><span class="labell">Vehicle Type: </span><span class="VehicleType value" ></span></p>
                                        <p><span class="labell">Vehicle Number:</span> <span class="VehicleNumber value"></span></p>
                                        <p><span class="labell">Driver Name:</span> <span class="DriverName value"></span></p>
                                        <p><span class="labell">Driver Payment:</span> <span class="DriverAmount value"></span></p>
                                        <p><span class="labell">Hamali Charges:</span> <span class="HamaliCharges value"></span></p>
                                        <p><span class="labell">Remarks:</span> <span class="Remarks value"></span></p>
                                        
                                        
                                        
                                        </div>
         
           
          <div class="clearfix"></div>
          
                                            
                                            
                                            
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                            <a href='' class="btn btn-primary transporthyperlink">Edit</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
<!-- Transport modal pop up ends here-->

<!-- Expenses modal popup starts here-->

<div class="modal fade" id="expenses" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                            <h4 class="modal-title expenses-lrno" id="myModalLabel">Modal title Here</h4>
                                        </div>
                                        <div class="modal-body expenses_body">
                                            
                                            <div class="col-md-4 name"  style="border:1px solid #eee">
                                                <div class="text-primary expensives_heading">Penalties</div>
                                               
                                               <div class="penalities">
                                                           <!-- <p><span class="labell">Transport Amount: </span><span class="TransportAmount value" ></span></p>
                                                            <p><span class="labell">Transport Amount: </span><span class="TransportAmount value" ></span></p>
                                                            
                                                            <p><span class="labell">Transport Amount: </span><span class="TransportAmount value" ></span></p>
                                                            <a href='' class="btn btn-primary btn-sm pull-right">Edit</a>-->
                                               </div>
                                            </div>
                                            
                                            <div class="col-md-4 name "  style="border:1px solid #eee">
                                            
                                            <div class="text-primary expensives_heading">Repairs</div>
                                           <div class="repairs">
                                                   <!-- <p><span class="labell">Transport Amount: </span><span class="TransportAmount value" ></span></p>
                                                    <p><span class="labell">Transport Amount: </span><span class="TransportAmount value" ></span></p>
                                                    <p><span class="labell">Transport Amount: </span><span class="TransportAmount value" ></span></p>
    <a href='' class="btn btn-success pull-right btn-sm ">Edit</a>-->
                                           </div>
                                            
                                            </div>
                                            
                                            <div class="col-md-4 name "  style="border:1px solid #eee">
    
                                               <div class="text-primary expensives_heading">Expesnses</div>
                                           <div class="expens">
                                                        <!--<p><span class="labell">Transport Amount: </span><span class="TransportAmount value" ></span></p>
                                                        <p><span class="labell">Transport Amount: </span><span class="TransportAmount value" ></span></p>
                                                        <p><span class="labell">Transport Amount: </span><span class="TransportAmount value" ></span></p>
                                                        <a href='' class="btn btn-danger pull-right btn-sm ">Edit</a>-->
                                            
                                           </div>
                                          
                                            </div>
             
                                             <div class="clearfix"></div>
                  
                                        </div>
                                        
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>

<!-- Expenses modal popup ends here-->

    </div>
    <!-- /. WRAPPER  -->
    <footer align='center'>
        Developed by <a href="http://www.trillionit.com" target="_blank"> TrillionIt Services PVT LTD</a>
    </footer>
    <!-- /. FOOTER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
<script>
var base_url = "<?PHP echo base_url();?>";
</script>
    <script src="resources/template-assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="resources/template-assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="resources/template-assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="resources/template-assets/js/custom.js"></script>
    

<script  src="resources/custom-assests/js/jquery-ui.js"></script>
<script src="resources/custom-assests/js/scripts.js"></script>
<script >

	 
	 
$(function() {

	$(".lrnos").autocomplete({
		 source: base_url+"Requestdispatcher/getlrnos",
		// type:'POST'
	});				
	
	$(".customers, #Consignee").autocomplete({
		 source: base_url+"Requestdispatcher.php?func=getcustomers",
		// type:'POST'
	});	
	
	

	/*

	$(".driver").autocomplete({
		 source: base_url+"Requestdispatcher/getdrivers",
		// type:'POST'
	});
	*/
	
	//
	$(".Articledescription").autocomplete({
		 source: base_url+"Requestdispatcher/getarticles",
		// type:'POST'
	});

		$(".vechilenumber").autocomplete
										({
		 									source: base_url+"Requestdispatcher.php?func=getvechilenumber",
										});
						
	
	$( "#lrdate, .lrdate,#dated,#todate,#frmdate" ).datepicker({dateFormat:"d-mm-yy"});
	
});



</script>


</body>
</html>
